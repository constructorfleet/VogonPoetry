"""Main module for the Vogon Poetry package."""
from vogonpoetry.logging import setup_logging


setup_logging()