"""
Module containing the metrics plugins for Vogon Poetry.
This module is responsible for exposing metrics to various backends.
"""