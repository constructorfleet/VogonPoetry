"""
The pipeline module is responsible for the orchestration of the entire
Vogon Poetry pipeline.
"""