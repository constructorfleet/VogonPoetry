"""Prometheus metrics configuration."""
