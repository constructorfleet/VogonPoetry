"""This module is responsible for exposing Prometheus metrics."""
# from prometheus_client import start_http_server

# start_http_server(8001)  # Prometheus metrics endpoint